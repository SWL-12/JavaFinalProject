package org.example.vebinarcrud.controllers;

import org.example.vebinarcrud.models.WebNote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.example.vebinarcrud.dao.WebNoteDAO;

@Controller
@RequestMapping("/notes")
public class NotesController {

    private final WebNoteDAO webNoteDAO;

    @Autowired
    public NotesController(WebNoteDAO webNoteDAO) { // инициализируем контроллер
        this.webNoteDAO = webNoteDAO;
    }

    @GetMapping() // возвращает индекс данной страницы
    public String index(Model model) {
        model.addAttribute("notes",webNoteDAO.index());
        return "notes/index";
    }

    @GetMapping("/{id}") // передаём id модели и получаем данные
    public String show(@PathVariable("id") int id, Model model) {
        model.addAttribute("note", webNoteDAO.show(id));
        return "notes/show";
    }

    @GetMapping("/new") // создаём новую заметку
    public String newNote(Model model) {
        model.addAttribute("webNote", new WebNote());
        return "notes/new";
    }

    @PostMapping() // добавляем новую заметку
    public String create(@ModelAttribute("webNote") WebNote webNote) {
        webNoteDAO.save(webNote);
        return "redirect:/notes";
    }

    @GetMapping("/{id}/edit") // изменение заметки
    public String edit(Model model, @PathVariable("id") int id) {
        model.addAttribute("webNote",webNoteDAO.show(id));
        return "notes/edit";
    }

    @PatchMapping("/{id}") // обновление заметки
    public String update(@ModelAttribute("webNote") WebNote webNote, @PathVariable("id") int id) {
        webNoteDAO.update(id, webNote);
        return "redirect:/notes";
    }

    @DeleteMapping("/{id}") // удаление заметки
    public String delete(@PathVariable("id") int id) {
        webNoteDAO.delete(id);
        return "redirect:/notes";
    }

}


